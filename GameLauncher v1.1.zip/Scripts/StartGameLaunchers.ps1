#This starts all three of the launchers. The last one starts the MS Store
Start-Process -FilePath "C:\Program Files (x86)\Steam\steam.exe"
Start-Process -FilePath "C:\Program Files (x86)\Epic Games\Launcher\Portal\Binaries\Win32\EpicGamesLauncher.exe"
Start-Process -FilePath "C:\Program Files (x86)\Battle.net\Battle.net Launcher.exe"
Start-Process -FilePath "C:\Program Files\Electronic Arts\EA Desktop\EA Desktop\EALauncher.exe"
start ms-windows-store: